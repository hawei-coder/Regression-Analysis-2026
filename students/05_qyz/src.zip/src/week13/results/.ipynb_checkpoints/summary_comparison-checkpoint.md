# Week13 Summary

## Forward Selection
['x1', 'x4', 'x5', 'x6', 'x8']

## Lasso Variables
['x1', 'x4', 'x5', 'x6', 'x8']