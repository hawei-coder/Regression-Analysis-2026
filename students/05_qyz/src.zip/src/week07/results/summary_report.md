# Week 7: 优化引擎与泛化能力实验报告

## 1. GradientDescentOLS 实现说明

### 核心原理

梯度下降通过迭代更新参数来最小化损失函数（MSE）：

$$\frac{\partial L}{\partial \beta} = \frac{2}{n} X^T (X\beta - y)$$

参数更新公式：$\beta = \beta - \eta \cdot \nabla L$

### 关键特性

| 特性 | 实现方式 | 说明 |
|------|----------|------|
| 学习率 | `learning_rate` | 控制每次更新的步长 |
| 收敛判断 | `tol` | 连续两次 loss 变化小于阈值时停止 |
| 批量策略 | `gd_type` | 支持 `full_batch` 和 `mini_batch` |
| 随机采样 | `batch_fraction` | Mini Batch 时随机抽取指定比例样本 |
| 截距处理 | `fit_intercept` | 自动在 X 前添加全 1 列 |

### 代码核心逻辑

```python
def _compute_gradient(self, X, y):
    n = X.shape[0]
    y_pred = X @ self.coef_
    error = y_pred - y
    return (2 / n) * (X.T @ error)

def fit(self, X, y):
    for epoch in range(max_iter):
        gradient = self._compute_gradient(X_batch, y_batch)
        self.coef_ -= self.learning_rate * gradient
        if abs(loss - prev_loss) < tol: break
```

## 2. 最佳学习率

**最佳学习率**: `0.1`

### 学习率调参结果

| 学习率 | Val R² | Val Adj R² | Val RMSE | 收敛轮数 | 状态 |
|--------|--------|------------|----------|----------|------|
| 0.100000 | 0.9009 | 0.8993 | 72.3167 | 1000 | ✓ 最佳 |
| 0.050000 | 0.9005 | 0.8990 | 72.4372 | 1000 | 未完全收敛 |
| 0.010000 | 0.9003 | 0.8988 | 72.5033 | 1000 | 未完全收敛 |
| 0.005000 | 0.9005 | 0.8990 | 72.4450 | 1000 | 未完全收敛 |
| 0.001000 | 0.5970 | 0.5908 | 145.8038 | 1000 | 欠拟合 |
| 0.000100 | -9.0004 | -9.1535 | 726.2848 | 1000 | 发散 |
| 0.000010 | -13.2044 | -13.4218 | 865.5850 | 1000 | 发散 |

### 学习率影响分析

- **学习率 0.1**：收敛最快，Val R² = 0.9009，表现最佳
- **学习率 0.01-0.05**：稳定收敛，Val R² ≈ 0.9005
- **学习率 0.001**：收敛缓慢，Val R² = 0.5970，欠拟合
- **学习率 ≤0.0001**：无法收敛，R² 为负，模型发散

## 3. Test 集结果对比

| 模型 | R² | Adjusted R² | RMSE | 说明 |
|------|-----|-------------|------|------|
| GradientDescentOLS | 0.890913 | 0.889243 | 78.533318 | ✓ 梯度下降成功逼近解析解 |
| AnalyticalOLS | 0.890222 | 0.888542 | 78.781582 | 基准模型（理论最优解） |

### 结果解读

- **R² 差异**: 0.000691
- **Adjusted R² 差异**: 0.000701
- **结论**: 梯度下降成功逼近解析解，验证了梯度下降实现的正确性

## 4. 标准化与防止数据泄露

### 为什么需要标准化？

梯度下降对特征尺度非常敏感。如果特征量纲不同（如 TV_Budget 范围 0-300，Social_Budget 范围 0-200），
梯度下降会沿着尺度大的特征方向震荡，导致收敛缓慢甚至不收敛。

### 正确的标准化流程

```python
# 1. 先划分数据集
X_train, X_temp, y_train, y_temp = train_test_split(X, y, test_size=0.4)
X_val, X_test, y_val, y_test = train_test_split(X_temp, y_temp, test_size=0.5)

# 2. 用 Train 集拟合 StandardScaler
scaler = StandardScaler()
X_train_scaled = scaler.fit_transform(X_train)  # fit + transform

# 3. Val/Test 只做变换（不重新 fit）
X_val_scaled = scaler.transform(X_val)   # 只 transform
X_test_scaled = scaler.transform(X_test) # 只 transform
```

### 如何防止数据泄露？

| 步骤 | 正确做法 | 错误做法 | 原因 |
|------|----------|----------|------|
| 划分数据 | **先划分，后标准化** | 先标准化，后划分 | Test 集信息会泄露到 Train 集 |
| 计算统计量 | **只用 Train 集** | 用全量数据 | 会引入 Test 集的均值和标准差 |
| 变换 Val/Test | **只 transform** | 重新 fit_transform | 会使用 Val/Test 自己的统计量 |

### 数据泄露的危害

如果先标准化再划分数据：
1. Test 集的均值/标准差会被用于标准化 Train 集
2. 模型提前看到了 Test 集的信息
3. 验证结果过于乐观，无法反映真实泛化能力
4. 部署到新数据时性能会大幅下降

### 本实验的标准化实现

```python
# prepare_data() 函数中的实现
scaler = StandardScaler()
X_train_scaled = scaler.fit_transform(X_train)  # 只用 Train 集 fit
X_val_scaled = scaler.transform(X_val)         # Val 只变换
X_test_scaled = scaler.transform(X_test)       # Test 只变换
```
✅ 确保 Val 和 Test 集信息不会泄露到模型训练中

## 5. 可视化

![学习曲线](learning_curve_full_vs_mini.png)

**学习曲线解读**：
- **蓝色线 (Full Batch)**：曲线平滑，稳定下降
- **橙色线 (Mini Batch)**：曲线有波动，但收敛更快，计算成本更低

## 6. 总结

| 任务 | 完成情况 | 关键结论 |
|------|----------|----------|
| Task 1 | ✅ | 成功实现 `GradientDescentOLS`，支持 Full/Mini Batch |
| Task 2 | ✅ | 5折交叉验证 R² ≈ 0.997，模型泛化能力良好 |
| Task 3 | ✅ | 最佳学习率 = 0.1，过小（≤0.0001）会发散 |
| Task 4 | ✅ | 梯度下降与解析解结果一致，验证实现正确 |

**核心收获**：
1. 梯度下降是解析解在大数据场景下的实用替代方案
2. 学习率需要调参：过大会发散，过慢收敛
3. Mini Batch 比 Full Batch 更快，适合大数据集
4. 标准化必须基于 Train 集，防止数据泄露
5. Adjusted R² 比 R² 更公平，能惩罚多余特征
